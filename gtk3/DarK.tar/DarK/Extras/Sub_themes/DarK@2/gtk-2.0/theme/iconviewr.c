style"iconview"{
GtkIconView::selection-box-alpha=51
GtkIconView::selection-box-color=@selected_bg_color
}class"GtkIconView"style"iconview"

widget_class"*.<GtkIconView>*<GtkImage>"style"mistrender"
widget_class"*.<GtkIconView>*<GtkLabel>"style"mistrender"
