style"textview"{
font_name="mono"
GtkTextView::error_bg_color=@error_bg_color
}class"GtkTextView"style"textview"

widget_class"*.<GtkIconView>*<GtkImage>"style"mistrender"
widget_class"*.<GtkIconView>*<GtkLabel>"style"mistrender"
