WinAMP 2.9x Skin by sixsixfive under CC-by-sa_V4(https://creativecommons.org/licenses/by-sa/4.0/)
ver: 1.0 final
